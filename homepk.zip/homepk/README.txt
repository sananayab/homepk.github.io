
TITLE: 
Homepk - 100% Fully Responsive Bootstrap website

AUTHOR:
DESIGNED & DEVELOPED by sana nayab

Website: http://sprotfolio.000webhostapp.com/
Twitter: http://twitter.com/nayabsana
Facebook: http://facebook.com/sanach


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Google Map
http://maps.google.com/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/sananayab/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Flexslider 
http://flexslider.woothemes.com

